# Vikas Mali Portfolio Website

A responsive, no-photo personal portfolio website built with HTML, CSS, and JavaScript.

## Preview locally
Open `index.html` in any modern browser.

## Before publishing
- Add your real email address and LinkedIn profile in the Contact section.
- Review the education details and project descriptions for accuracy.
- The GitHub button currently links to the DriveMate repository URL supplied in the conversation.

## Publish free with GitHub Pages
1. Create a new GitHub repository (for example, `vikas-portfolio`).
2. Upload `index.html` to the repository root.
3. Open repository Settings → Pages.
4. Under Build and deployment, choose Deploy from a branch, select `main` and `/ (root)`, then Save.
5. Wait for GitHub Pages to publish the site and open the URL it provides.
